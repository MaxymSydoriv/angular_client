import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { throwError } from 'rxjs';

import { AuthService } from 'src/app/common/services/auth.service';
import { AdditionalService } from 'src/app/common/services/additional.service';
import { City } from '../../common/classes/city';
import { contactTypes as types } from '../../common/mocks/mockContactTypes';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {
  formReg: FormGroup;
  countries: string[];
  cities: City[];
  contactTypes: string[];
  hasFailed: boolean;
  showPassword: boolean;
  error: string;

  constructor(
    private readonly authService: AuthService,
    public router: Router,
    public additinalservice: AdditionalService) { }


  ngOnInit() {
    this.contactTypes = types;
    this.formReg = new FormGroup({
      login: new FormControl('', [
        Validators.required,
        Validators.minLength(5),
        Validators.maxLength(10)]),
      password: new FormControl('', [
        Validators.required,
        Validators.pattern(/^(?=.*?[A-Z]{1,})(?=.*?[#?!@$%^&*-]{1,})/),
        Validators.minLength(5)]),
      name: new FormControl('', [
        Validators.required,
        Validators.maxLength(10)]),
      surname: new FormControl('', [
        Validators.required,
        Validators.maxLength(12)]),
      contact: new FormGroup({
        contactType: new FormControl(null),
        contactValue: new FormControl(null)
      }),
      country: new FormControl('', Validators.required),
      city: new FormControl('', Validators.required)
    });
    this.additinalservice.getCountries()
      .subscribe(countries => this.countries = countries.sort());
  }

  getCities(): void {
    const country = this.formReg.get('country').value;

    this.additinalservice.getCities(country)
      .subscribe(cities => {
        this.cities = cities.sort((a, b) => {
          if (a.city < b.city) { return -1; }
          if (a.city > b.city) { return 1; }
          return 0;
        });
      });
  }

  onSubmit(): void {
    this.authService.signUp(this.formReg.value)
      .subscribe(
        (res) => {
          this.authService.parseToken(res);
        },
        (err) => {
          this.error = err.error.errorMessage;
        },
        () => {
          this.router.navigate(['/home'])
            .catch(err => throwError(new Error(err)));
        }
      );
  }
}

