import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginizationComponent } from './loginization.component';

describe('LoginizationComponent', () => {
  let component: LoginizationComponent;
  let fixture: ComponentFixture<LoginizationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginizationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginizationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
