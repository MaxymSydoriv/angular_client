import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { throwError } from 'rxjs';

import { AuthService } from 'src/app/common/services/auth.service';

@Component({
  selector: 'app-loginization',
  templateUrl: './loginization.component.html',
  styleUrls: ['./loginization.component.scss']
})
export class LoginizationComponent implements OnInit {
  formLog: FormGroup;
  hasFailed: boolean;
  showPassword: boolean;
  error: string;

  constructor(
    private readonly authService: AuthService,
    public router: Router) {}

  ngOnInit() {
    this.formLog = new FormGroup({
      login: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required)
    });
  }

  onSubmit(): void {
    this.authService.signIn(this.formLog.value)
      .subscribe(
        (res) => {
          this.authService.parseToken(res);
        },
        (err) => {
          this.error = err.error.errorMessage;
        },
        () => {
          this.router.navigate(['/home'])
            .catch(err => throwError(new Error(err)));
        }
      );
  }

}
