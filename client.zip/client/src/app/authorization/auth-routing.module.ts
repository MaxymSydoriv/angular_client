import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthorizationComponent } from './authorization.component';
import { LoginizationComponent } from './loginization/loginization.component';
import { RegistrationComponent } from './registration/registration.component';

const routes: Routes = [
  {
    path: '', component: AuthorizationComponent, children: [
      { path: '', redirectTo: 'signin' },
      { path: 'signin', component: LoginizationComponent },
      { path: 'signup', component: RegistrationComponent },
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
