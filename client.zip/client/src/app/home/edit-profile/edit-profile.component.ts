import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { throwError } from 'rxjs';

import { AuthService } from 'src/app/common/services/auth.service';
import { AdditionalService } from 'src/app/common/services/additional.service';
import { City } from '../../common/classes/city';
import { contactTypes as types } from '../../common/mocks/mockContactTypes';
import { User, Contact } from 'src/app/common/classes/user';
import { UserService } from 'src/app/common/services/user.service';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.scss']
})
export class EditProfileComponent implements OnInit {

  formEdit: FormGroup;
  countries: string[];
  cities: City[];
  contactTypes: string[];
  user: User;

  constructor(
    private readonly authService: AuthService,
    public router: Router,
    public additinalservice: AdditionalService,
    public userService: UserService) { }


  ngOnInit() {
    this.contactTypes = types;
    this.userService.takeUser
      .subscribe(user => {
        this.user = user;
        this.getCities();
      });
    this.formEdit = new FormGroup({
      name: new FormControl(this.user.name, [
        Validators.required,
        Validators.maxLength(20)]),
      surname: new FormControl(this.user.surname, [
        Validators.required,
        Validators.maxLength(20)]),
      contact: new FormGroup({
        contactType: new FormControl(this.user.contact.contactType),
        contactValue: new FormControl(this.user.contact.contactValue)
      }),
      country: new FormControl(this.user.country, Validators.required),
      city: new FormControl(this.user.city, Validators.required)
    });
    this.additinalservice.getCountries()
      .subscribe(countries => this.countries = countries.sort());
  }

  getCities(): void {
    const country = this.user.country;

    this.additinalservice.getCities(country)
      .subscribe(cities => {
        this.cities = cities.sort((a, b) => {
          if (a.city < b.city) { return -1; }
          if (a.city > b.city) { return 1; }
          return 0;
        });
      });
  }

  onSubmit(): void {
    const editedUser = Object.assign(this.user, this.formEdit.value);
    this.userService.editeUser(editedUser)
      .subscribe(user => {
        this.userService.takeUser.next(user);
        this.router.navigate(['/home/profile'])
          .catch(err => throwError(new Error(err)));
      });
  }

}
