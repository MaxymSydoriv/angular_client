import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/common/classes/user';
import { UserService } from 'src/app/common/services/user.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
  user: User;
  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.takeUser
      .subscribe(user => this.user = user);
  }


  getFullName(): string {
    if (this.user) {
      return `${this.user.name} ${this.user.surname}`;
    }
  }

  getContact(): string {
    if (this.user.contact) {
      return `${this.user.contact.contactType} is ${this.user.contact.contactValue}`;
    }
  }
}
