import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { throwError } from 'rxjs';

import { UserService } from '../common/services/user.service';
import { User } from '../common/classes/user';
import { AuthService } from '../common/services/auth.service';
import { NAVBAR_LIST } from '../common/mocks/mockNavItems';
import { NavItem } from '../common/classes/navItem';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  user: User;
  navItems: NavItem[];
  constructor(
    private userService: UserService,
    private authService: AuthService,
    private router: Router) { }

  ngOnInit() {
    this.navItems = NAVBAR_LIST;
    this.userService.getUser()
      .subscribe(user => {
        this.user = user;
        this.userService.takeUser.next(user);
      });
  }

  deleteProfile(): boolean {
    this.userService.deleteUser(this.user._id)
      .subscribe(() => this.logout());

    return false;
  }

  logout(): boolean {
    this.authService.logout();
    this.router.navigate(['/auth'])
      .catch(err => throwError(new Error(err)));

    return false;
  }

}
