import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';

import { LoggedOutGuard } from './common/guards/logged-out.guard';
import { LoggedInGuard } from './common/guards/logged-in.guard';


const routes: Routes = [
  { path: '', redirectTo: 'auth', pathMatch: 'full' },
  { path: 'auth', loadChildren: './authorization/auth.module#AuthModule', canLoad: [LoggedOutGuard]  },
  { path: 'home', loadChildren: './home/home.module#HomeModule', canLoad: [LoggedInGuard] },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    preloadingStrategy: PreloadAllModules
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
