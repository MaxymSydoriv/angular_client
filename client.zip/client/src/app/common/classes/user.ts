export class User {
  constructor(
    public login: string = '',
    public password: string = '',
    public name: string = '',
    public surname: string = '',
    public city: string = '',
    public country: string = '',
    public contact?: Contact,
    public _id?: string,
    ) {
  }
}

export class Contact {
  constructor(
    public contactType: string = '',
    public contactValue: string = ''
  ) {}
}

export const mUser = {
  login: '',
  password: '',
  name: '',
  surname: '',
  city: '',
  country: '',
  contact: {
    contactType: '',
    contactValue: ''
  },
  _id: ''
};

