export class City {
  constructor(
    public city: string,
    public cityAscii: string,
    public lat: string,
    public lng: string,
    public country: string,
    public iso2: string,
    public iso3: string,
    public adminName: string,
    public capital: string,
    public population: null,
    public id: number) {
  }
}
