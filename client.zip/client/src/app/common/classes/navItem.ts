export class NavItem {
  constructor(
    public title: string,
    public route: string,
    ) {}
}
