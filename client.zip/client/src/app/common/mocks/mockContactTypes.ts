export const contactTypes = [ 'phone', 'viber', 'skype', 'email' ];
