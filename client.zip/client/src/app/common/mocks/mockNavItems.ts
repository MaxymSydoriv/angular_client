import { NavItem } from '../classes/navItem';


export const NAVBAR_LIST: NavItem[] = [
  {
    title: 'profile',
    route: '/home/profile',
  },
  {
    title: 'edit profile',
    route: '/home/edit-profile',
  }
];
