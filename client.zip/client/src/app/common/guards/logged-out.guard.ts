import { Injectable } from '@angular/core';
import { Router, Route, ActivatedRouteSnapshot, RouterStateSnapshot, CanActivate, CanLoad } from '@angular/router';
import { Observable } from 'rxjs';

import { AuthService } from '../services/auth.service';

@Injectable({
  providedIn: 'root'
})

export class LoggedOutGuard implements CanLoad {
  constructor(private readonly authService: AuthService, private readonly router: Router) { }

  canLoad(route: Route): Observable<boolean> | Promise<boolean> | boolean {
    const isLoggedIn = this.authService.isLoggedIn();

    if (isLoggedIn) {
      this.router.navigate(['/home'])
        .catch(err => {
          console.log(err);
        });

      return false;
    }

    return true;
  }
}


