import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

import { api } from '../../../config/config';
import { City } from '../../common/classes/city';

@Injectable({
  providedIn: 'root'
})

export class AdditionalService {

  constructor(private http: HttpClient) { }

  getCountries(): Observable<string[]> {
    return this.http.get<string[]>(`${api}cities`);
  }

  getCities(country: string): Observable<City[]> {
    const body = ({ country });
    return this.http.post<City[]>(`${api}cities`, body);
  }
}
