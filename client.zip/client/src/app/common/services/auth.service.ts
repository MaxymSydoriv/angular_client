import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { api } from '../../../config/config';

import { User } from '../../common/classes/user';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private readonly http: HttpClient) { }

  signIn(request): Observable<object> {
    return this.http.post<object>(`${api}authenticate/login`, request);
  }

  signUp(user: User): Observable<User> {
    return this.http.post<User>(`${api}authenticate/signup`, user);
  }

  parseToken(response): void {
    localStorage.setItem('frajtoken', response.token);
  }

  isLoggedIn(): boolean {
    const token = localStorage.getItem('frajtoken');

    return token !== null;
  }

  logout(): void {
    localStorage.clear();
  }

}

export const AUTH_PROVIDERS: Array<any> = [
  { provide: AuthService, useClass: AuthService }
];
