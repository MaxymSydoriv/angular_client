import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { JwtHelperService } from '@auth0/angular-jwt';

import { api } from '../../../config/config';
import { User, mUser } from '../classes/user';



export const httpOptions = () => {
  return {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${localStorage.getItem('frajtoken')}`
    })
  };
};

@Injectable({
  providedIn: 'root'
})

export class UserService {
  // user = new User();
  helper = new JwtHelperService();
  public takeUser: BehaviorSubject<User> = new BehaviorSubject(mUser);

  constructor(private readonly http: HttpClient) {
  }

  getUser(): Observable<User> {
    const id = this.getUserId();

    return this.http.get<User>(`${api}users/${id}`, httpOptions());
  }

  editeUser(editedUser: User): Observable<User> {
    return this.http.put<User>(`${api}users`, editedUser, httpOptions());
  }

  deleteUser(id: string): Observable<object> {
    return this.http.delete<User>(`${api}users/${id}`, httpOptions());
  }

  getUserId(): any {
    return this.helper.decodeToken(localStorage.frajtoken).id;
  }
}
